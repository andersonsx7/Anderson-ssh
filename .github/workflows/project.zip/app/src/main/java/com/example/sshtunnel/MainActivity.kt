package com.example.sshtunnel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val txt = InputType.TYPE_CLASS_TEXT

        fun field(hint: String, value: String, type: Int) = EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = type
            setSingleLine()
        }

        val host = field("Servidor SSH (ex: meuserver.com)", p.getString("host", "") ?: "", txt or InputType.TYPE_TEXT_VARIATION_URI)
        val port = field("Porta SSH", p.getString("port", "22") ?: "22", InputType.TYPE_CLASS_NUMBER)
        val user = field("Usuário", p.getString("user", "") ?: "", txt)
        val pass = field("Senha", "", txt or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val local = field("Porta SOCKS local", p.getString("local", "1080") ?: "1080", InputType.TYPE_CLASS_NUMBER)

        val title = TextView(this).apply {
            text = "SSH Tunnel"
            textSize = 26f
            setPadding(0, pad, 0, pad)
        }
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad, 0, pad)
        }
        btn = Button(this)

        btn.setOnClickListener {
            val svc = Intent(this, TunnelService::class.java)
            if (TunnelService.active) {
                stopService(svc)
            } else {
                p.edit()
                    .putString("host", host.text.toString().trim())
                    .putString("port", port.text.toString())
                    .putString("user", user.text.toString().trim())
                    .putString("local", local.text.toString())
                    .apply()
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                svc.putExtra("host", host.text.toString().trim())
                    .putExtra("port", port.text.toString().toIntOrNull() ?: 22)
                    .putExtra("user", user.text.toString().trim())
                    .putExtra("pass", pass.text.toString())
                    .putExtra("local", local.text.toString().toIntOrNull() ?: 1080)
                TunnelService.active = true
                TunnelService.statusText = "Conectando…"
                refresh()
                startForegroundService(svc)
            }
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            listOf(title, host, port, user, pass, local, btn, status).forEach { addView(it) }
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun refresh() {
        btn.text = if (TunnelService.active) "Desconectar" else "Conectar"
        status.text = TunnelService.statusText
    }

    override fun onResume() {
        super.onResume()
        TunnelService.onChange = { runOnUiThread { refresh() } }
        refresh()
    }

    override fun onPause() {
        super.onPause()
        TunnelService.onChange = null
    }
}
