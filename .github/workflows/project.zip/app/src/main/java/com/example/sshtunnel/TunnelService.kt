package com.example.sshtunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import java.io.DataInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException

class TunnelService : Service() {
    companion object {
        @Volatile var active = false
        @Volatile var statusText = "Desconectado"
        @Volatile var onChange: (() -> Unit)? = null
        fun set(text: String) {
            statusText = text
            onChange?.invoke()
        }
    }

    private var worker: Thread? = null
    @Volatile private var stop = false
    @Volatile private var session: Session? = null
    @Volatile private var server: ServerSocket? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (worker?.isAlive == true) return START_NOT_STICKY
        active = true
        stop = false
        val host = intent.getStringExtra("host") ?: ""
        val port = intent.getIntExtra("port", 22)
        val user = intent.getStringExtra("user") ?: ""
        val pass = intent.getStringExtra("pass") ?: ""
        val local = intent.getIntExtra("local", 1080)
        worker = Thread { runTunnel(host, port, user, pass, local) }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun runTunnel(host: String, port: Int, user: String, pass: String, localPort: Int) {
        try {
            set("Conectando…")
            val s = JSch().getSession(user, host, port)
            s.setPassword(pass)
            // Aceita qualquer chave de host (simples, mas menos seguro)
            s.setConfig("StrictHostKeyChecking", "no")
            s.setConfig("PreferredAuthentications", "password")
            s.setServerAliveInterval(30000)
            s.connect(15000)
            session = s

            val ss = ServerSocket(localPort, 50, InetAddress.getByName("127.0.0.1"))
            ss.soTimeout = 3000
            server = ss
            set("Conectado. SOCKS5 em 127.0.0.1:$localPort")

            while (!stop) {
                if (!s.isConnected) throw Exception("conexão SSH caiu")
                try {
                    val c = ss.accept()
                    Thread { handle(c, s) }.start()
                } catch (_: SocketTimeoutException) {
                }
            }
        } catch (e: Exception) {
            if (!stop) set("Erro: ${e.message}")
        } finally {
            cleanup()
            stopSelf()
        }
    }

    private fun handle(c: Socket, s: Session) {
        var ch: ChannelDirectTCPIP? = null
        try {
            c.tcpNoDelay = true
            val inp = DataInputStream(c.getInputStream())
            val out = c.getOutputStream()

            if (inp.readUnsignedByte() != 5) return
            val n = inp.readUnsignedByte()
            inp.readFully(ByteArray(n))
            out.write(byteArrayOf(5, 0))
            out.flush()

            if (inp.readUnsignedByte() != 5) return
            val cmd = inp.readUnsignedByte()
            inp.readUnsignedByte()
            val dst = when (inp.readUnsignedByte()) {
                1 -> {
                    val b = ByteArray(4); inp.readFully(b)
                    InetAddress.getByAddress(b).hostAddress ?: return
                }
                3 -> {
                    val l = inp.readUnsignedByte()
                    val b = ByteArray(l); inp.readFully(b)
                    String(b)
                }
                4 -> {
                    val b = ByteArray(16); inp.readFully(b)
                    InetAddress.getByAddress(b).hostAddress ?: return
                }
                else -> { reply(out, 8); return }
            }
            val dport = inp.readUnsignedShort()
            if (cmd != 1) { reply(out, 7); return }

            val channel = s.openChannel("direct-tcpip") as ChannelDirectTCPIP
            ch = channel
            channel.setHost(dst)
            channel.setPort(dport)
            val rin = channel.inputStream
            val rout = channel.outputStream
            try {
                channel.connect(10000)
            } catch (e: Exception) {
                reply(out, 5)
                return
            }
            reply(out, 0)

            Thread {
                copy(inp, rout)
                try { rout.close() } catch (_: Exception) {}
            }.start()
            copy(rin, out)
        } catch (_: Exception) {
        } finally {
            try { ch?.disconnect() } catch (_: Exception) {}
            try { c.close() } catch (_: Exception) {}
        }
    }

    private fun reply(out: OutputStream, code: Int) {
        out.write(byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0))
        out.flush()
    }

    private fun copy(i: InputStream, o: OutputStream) {
        try {
            val buf = ByteArray(16384)
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                o.flush()
            }
        } catch (_: Exception) {
        }
    }

    private fun cleanup() {
        try { server?.close() } catch (_: Exception) {}
        try { session?.disconnect() } catch (_: Exception) {}
        server = null
        session = null
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("tunnel", "Túnel SSH", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, "tunnel")
            .setContentTitle("Túnel SSH ativo")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stop = true
        cleanup()
        active = false
        set(if (statusText.startsWith("Erro")) statusText else "Desconectado")
        super.onDestroy()
    }
}
